jquery-mortgage
===============

Simple jQuery based mortgage calculator with amortization.