<?php

//include ('connect.php');

$company_name=$_GET['vpb_fullname'];
$address=$_POST['address'];
$email=$_POST['email'];
$phoneno=$_POST['phone'];
$service=$_POST['service'];

echo $company_name;