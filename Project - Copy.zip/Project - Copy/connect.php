<?php
// create connection

$con=mysqli_connect("localhost","root","pass","project;
if(mysqli_connect_errno()){
	echo "Failed to connect to Mysql".mrsqli_connect_errno();
	
}
?>