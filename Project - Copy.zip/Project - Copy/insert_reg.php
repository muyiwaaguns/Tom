<?php

$SuccessRedirect	= 'index.html'; //Redirect to a URL after success

// replace with your mysql database details

$MySql_username 	= "root"; //mysql username
$MySql_password 	= ""; //mysql password
$MySql_hostname 	= "localhost"; //hostname
$MySql_databasename = 'mangrove'; //databasename


if($_POST)
{
	if(!isset($_POST['name']) || strlen($_POST['name'])<1)
	{
		//required variables are empty
		die("Name is empty!");
	}



	$uploaded_date		= date("Y-m-d H:i:s");
    $name               = mysql_real_escape_string($_POST['name']);
    $sex                = mysql_real_escape_string($_POST['sex']);
    $address            = mysql_real_escape_string($_POST['address']);
    $phone              = mysql_real_escape_string($_POST['phone']);
    $email              = mysql_real_escape_string($_POST['email']);
    $certificate        = mysql_real_escape_string($_POST['certificate']);





		//connect & insert file record in database
        $dbconn = mysql_connect($MySql_hostname, $MySql_username, $MySql_password)or die("Unable to connect to MySQL");
		mysql_select_db($MySql_databasename,$dbconn);

		@mysql_query("INSERT INTO registration (name, sex, contact_address,certificate, email, phone, date) VALUES ('$name', '$sex','$address','$certificate','$email','$phone','$uploaded_date')");
		mysql_close($dbconn);

		header('Location: '.$SuccessRedirect); //redirect user after success


}


?>